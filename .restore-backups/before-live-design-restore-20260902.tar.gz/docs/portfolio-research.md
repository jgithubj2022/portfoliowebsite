# Portfolio reference notes

Reviewed September 2026. Employment and graduation details below are self-reported on the authors’ public websites. No independent rating or evidence that a particular design caused an offer was found. The implementation uses original markup and styling, not copied repository code.

## Early-career references

- [Alexander Yuan](https://alexyuan66.github.io/) lists Yale BS/MS completion in 2025 and a Google software-engineering role beginning August 2025. His portfolio makes education, experience, projects, and contact information directly accessible. [Navigation source reviewed](https://github.com/alexyuan66/alexyuan66.github.io/blob/HEAD/js/scripts.js): section tracking, responsive navigation, and progressively disclosed details.
- [Dylan Zhuang](https://www.dylanzhuang.com/) describes a May 2026 graduation and a Google role, alongside internships. [Portfolio component reviewed](https://github.com/Dzeddy/dylan-portfolio/blob/HEAD/src/components/Portfolio.tsx) and [project-card component](https://github.com/Dzeddy/dylan-portfolio/blob/HEAD/src/components/ProjectCard.tsx): clear work/project hierarchy, restrained presentation, and distinct technology and external-link information.

## Established reference, not a new-graduate example

- [Brittany Chiang](https://brittanychiang.com/) provides a strong reference for concise project narratives and readable navigation. [Featured-project source reviewed](https://github.com/bchiang7/v4/blob/HEAD/src/components/sections/featured.js): image/text composition, direct code links, and reduced-motion handling. Her established career should not be represented as a new-graduate success story.

## Applied to this portfolio

- Keep the avatar as personal identity, with project evidence immediately visible.
- Replace the mandatory intro with optional playback.
- Provide stable section links and dedicated project URLs rather than hiding all work behind one panel.
- Separate project problem, implementation, architecture, and result.
- Tie skills to demonstrable projects; do not imply expertise through invented percentages.
- Preserve the four-theme selector and Xbox typography, with quieter metallic framing and readable body text.
- Keep motion optional and avoid rotating project text or interrupting navigation.
- Optimize the supplied animation rather than replacing the user’s avatar.

## Content provenance

Project descriptions derive from Jiles’s public repositories for [MangaBite](https://github.com/jgithubj2022/manga-tracker), [ThinkBoard](https://github.com/jgithubj2022/thinkboard-project), [MusicAffinity](https://github.com/jgithubj2022/music-affinity-calculator), and the team’s [SeaPredictor Devpost submission](https://devpost.com/software/seapredictor). SeaPredictor’s model is credited to the team; Jiles’s documented contribution is frontend creation and model integration.

No school, graduation date, work history, résumé, usage metric, or hiring outcome has been invented. Those sections can be added when Jiles supplies the relevant details.
