import Image from "next/image";
import Link from "next/link";
import { email, github, linkedin, projects } from "./content/projects";
import PortfolioControls from "./components/portfolio-controls";
import PortfolioNav from "./components/portfolio-nav";

export default function Home() {
  return (
    <div className="folio">
      <a className="folio-skip" href="#work">Skip to projects</a>
      <header className="folio-topbar"><a className="folio-wordmark" href="#top"><Image src="/avatar/profile.png" alt="" width={32} height={32} /> Jiles Smith <span>/ Portfolio</span></a></header>
      <div className="folio-layout" id="top">
        <aside className="folio-profile" aria-label="Profile">
          <div className="folio-profile-heading"><span className="folio-kicker">Personal profile</span><span aria-hidden="true">01</span></div>
          <h1>Jiles<br />Smith<span className="folio-period">.</span></h1>
          <p className="folio-introduction">I build web applications, browser tools, and interfaces for machine learning.</p>
          <PortfolioControls />
          <div className="folio-profile-links"><a href={github} target="_blank" rel="noreferrer">GitHub ↗</a><a href={linkedin} target="_blank" rel="noreferrer">LinkedIn ↗</a><a href={`mailto:${email}`}>Email ↗</a></div>
        </aside>
        <main className="folio-main">
          <PortfolioNav />
          <section id="work" className="folio-section" aria-labelledby="work-title">
            <div className="folio-section-heading"><div><p className="folio-kicker">01 / Selected work</p><h2 id="work-title">Built to be used.</h2></div><span className="folio-index">4 projects</span></div>
            <p className="folio-section-intro">From a marine-debris globe to voice-powered notes: a selection of applications and the engineering behind them.</p>
            <div className="folio-projects">{projects.map((project, index) => (
              <article className={`folio-project ${index === 0 ? "folio-featured" : ""}`} key={project.slug}>
                <Link className="folio-project-image" href={`/projects/${project.slug}`} aria-label={`Read about ${project.title}`}>
                  <div className="folio-windowbar"><span>{String(index + 1).padStart(2, "0")} / {project.category}</span><span aria-hidden="true">↗</span></div>
                  <Image src={project.image} alt={`${project.title} application interface`} width={960} height={488} sizes="(max-width: 760px) 95vw, (max-width: 1100px) 60vw, 750px" preload={index === 0} />
                </Link>
                <div className="folio-project-copy">
                  {project.award && <p className="folio-award"><span aria-hidden="true">★</span> {project.award}</p>}
                  <h3><Link href={`/projects/${project.slug}`}>{project.title}<span aria-hidden="true">↗</span></Link></h3>
                  <p>{project.description}</p><p className="folio-role">{project.role}</p>
                  <ul className="folio-tags" aria-label="Technologies">{project.technologies.map(tech => <li key={tech}>{tech}</li>)}</ul>
                  <div className="folio-project-actions"><Link href={`/projects/${project.slug}`}>Read project notes <span aria-hidden="true">→</span></Link><a href={project.url} target="_blank" rel="noreferrer">{project.award ? "Devpost" : "Source"} ↗</a></div>
                </div>
              </article>
            ))}</div>
          </section>
          <section id="about" className="folio-section" aria-labelledby="about-title">
            <div className="folio-section-heading"><div><p className="folio-kicker">02 / About & approach</p><h2 id="about-title">Curiosity, put to work.</h2></div></div>
            <div className="folio-about"><p>My projects follow the things I’m curious about: music, manga, useful browser tools, and the world beyond the screen. I enjoy connecting the interface people interact with to the systems that make it work.</p><p>That has meant integrating a team’s trained model into a 3D globe, connecting a browser extension to a notes API, and keeping machine-learning predictions separate from their generated explanations.</p></div>
            <a className="folio-recognition" href="https://devpost.com/software/seapredictor" target="_blank" rel="noreferrer"><span className="folio-medal" aria-hidden="true">★</span><span><small>Team recognition · FullyHacks 2026</small><strong>Best Use of AI/ML</strong><span>SeaPredictor — frontend & model integration</span></span><span aria-hidden="true">↗</span></a>
          </section>
          <section id="skills" className="folio-section" aria-labelledby="skills-title">
            <div className="folio-section-heading"><div><p className="folio-kicker">03 / Technical toolkit</p><h2 id="skills-title">Skills, with evidence.</h2></div></div>
            <div className="folio-skill-list">
              <div><h3>Interfaces</h3><p>React · Next.js · TypeScript · CSS · CesiumJS</p><Link href="/projects/seapredictor">Explore the SeaPredictor frontend →</Link></div>
              <div><h3>Applications & data</h3><p>Node.js · Express · MongoDB · PHP · MySQL</p><Link href="/projects/thinkboard">See the shared notes architecture →</Link></div>
              <div><h3>Models & integration</h3><p>Python · Supervised learning · Gemini · Web Speech API</p><Link href="/projects/music-affinity">See prediction and explanation →</Link></div>
            </div>
          </section>
          <section id="contact" className="folio-section folio-contact" aria-labelledby="contact-title">
            <p className="folio-kicker">04 / Contact</p><h2 id="contact-title">Let’s build something useful.</h2><p>Have a role, a project, or a question about my work? I’d like to hear from you.</p>
            <a className="folio-email" href={`mailto:${email}`}>{email}<span aria-hidden="true">↗</span></a>
            <div className="folio-contact-links"><a href={linkedin} target="_blank" rel="noreferrer">LinkedIn ↗</a><a href={github} target="_blank" rel="noreferrer">GitHub ↗</a></div>
          </section>
          <footer className="folio-footer"><span>Jiles Smith · Built with Next.js</span><a href="#top">Back to top ↑</a></footer>
        </main>
      </div>
    </div>
  );
}
