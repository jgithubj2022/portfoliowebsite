import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { projects } from "../../content/projects";

type Props = { params: Promise<{ slug: string }> };
export function generateStaticParams() {
  return projects.map(project => ({ slug: project.slug }));
}
export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const project = projects.find(item => item.slug === slug);
  if (!project) notFound();
  return { title: project.title, description: project.description };
}

export default async function ProjectPage({ params }: Props) {
  const { slug } = await params;
  const index = projects.findIndex(project => project.slug === slug);
  if (index < 0) notFound();
  const project = projects[index];
  const next = projects[(index + 1) % projects.length];
  return <div className="folio">
    <header className="folio-topbar"><Link className="folio-wordmark" href="/"><Image src="/avatar/profile.png" alt="" width={32} height={32} /> Jiles Smith <span>/ Project notes</span></Link></header>
    <main className="folio-case">
      <Link className="folio-back" href="/#work">← All projects</Link>
      <p className="folio-kicker">{String(index + 1).padStart(2, "0")} / {project.category}</p>
      <h1>{project.title}</h1><p className="folio-case-lead">{project.description}</p>
      <div className="folio-case-meta"><span>{project.role}</span><a href={project.url} target="_blank" rel="noreferrer">{project.award ? "View on Devpost" : "Explore source code"} ↗</a></div>
      <div className="folio-case-image"><Image src={project.image} alt={`${project.title} application screenshot`} width={960} height={488} sizes="(max-width: 1000px) 94vw, 930px" preload /></div>
      <div className="folio-case-content">
        <h2>The problem</h2><p>{project.challenge}</p>
        <h2>The approach</h2><ul>{project.approach.map(item => <li key={item}>{item}</li>)}</ul>
        <h2>How it connects</h2><ol className="folio-flow">{project.flow.map((step, index) => <li key={step}><span>0{index + 1} {index < project.flow.length - 1 ? "→" : ""}</span>{step}</li>)}</ol>
        <h2>The result</h2><p>{project.result}</p>
        <h2>Built with</h2><ul className="folio-tags">{project.technologies.map(tech => <li key={tech}>{tech}</li>)}</ul>
      </div>
      <Link className="folio-case-next" href={`/projects/${next.slug}`}><span><small>Next project</small>{next.title}</span><span aria-hidden="true">→</span></Link>
      <footer className="folio-footer"><Link href="/">← Back to portfolio</Link><Link href="/#contact">Get in touch ↗</Link></footer>
    </main>
  </div>;
}
