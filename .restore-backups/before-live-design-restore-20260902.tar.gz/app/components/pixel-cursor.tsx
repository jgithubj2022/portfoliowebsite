"use client";

import { useEffect, useId, useRef } from "react";

export default function PixelCursor({ enabled }: { enabled: boolean }) {
  const cursor = useRef<HTMLDivElement>(null);
  const gradientId = useId();
  useEffect(() => {
    if (!enabled) return;
    const fine = window.matchMedia("(hover: hover) and (pointer: fine)");
    const element = cursor.current;
    if (!element) return;
    const hide = () => {
      element.style.opacity = "0";
      element.classList.remove("is-pressed", "is-hovering");
      document.documentElement.classList.remove("pixel-cursor-active");
    };
    const move = (event: PointerEvent) => {
      if (!fine.matches || event.pointerType !== "mouse") { hide(); return; }
      element.style.transform = `translate3d(${event.clientX}px, ${event.clientY}px, 0)`;
      element.style.opacity = "1";
      document.documentElement.classList.add("pixel-cursor-active");
      const target = event.target instanceof Element ? event.target : null;
      element.classList.toggle("is-hovering", !!target?.closest("button:not(:disabled), a, summary, input, label, [role=button], .loading-screen"));
    };
    const down = () => element.classList.add("is-pressed");
    const up = () => element.classList.remove("is-pressed");
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerdown", down);
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", up);
    window.addEventListener("blur", hide);
    document.documentElement.addEventListener("pointerleave", hide);
    fine.addEventListener("change", hide);
    return () => {
      hide();
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerdown", down);
      window.removeEventListener("pointerup", up);
      window.removeEventListener("pointercancel", up);
      window.removeEventListener("blur", hide);
      document.documentElement.removeEventListener("pointerleave", hide);
      fine.removeEventListener("change", hide);
    };
  }, [enabled]);
  return (
    <div ref={cursor} className="pixel-cursor" aria-hidden="true">
      <span className="pixel-cursor-shape">
        <svg viewBox="0 0 30 40" focusable="false">
          <defs>
            <linearGradient id={gradientId} x1="0" y1="0" x2="1" y2="1">
              <stop offset="0" stopColor="#ffffff" />
              <stop offset=".45" stopColor="#e9f0f2" />
              <stop offset=".5" stopColor="#99abb5" />
              <stop offset="1" stopColor="#eff8fb" />
            </linearGradient>
          </defs>
          <path d="M1 1 L27 24 L17 25 L23 36 L17 39 L11 28 L3 35 Z" fill={`url(#${gradientId})`} stroke="#1e303b" strokeWidth="1.8" strokeLinejoin="round" />
          <path d="M4 7 L5 28 L11 22 L18 22 Z" fill="var(--color-primary)" stroke="#ffffff" strokeWidth=".8" />
          <path d="M2.5 3 L4 31 M13 27 L19 37" fill="none" stroke="#ffffff" strokeWidth="1.2" />
        </svg>
      </span>
    </div>
  );
}
