import type { Metadata } from "next";
import "./globals.css";
import "./retro.css";
import "./portfolio.css";
import ThemeControls from "./components/theme-controls";

export const metadata: Metadata = {
  title: { default: "Jiles Smith — Software Portfolio", template: "%s | Jiles Smith" },
  description: "Web applications, browser tools, and machine-learning interfaces by Jiles Smith. Explore project notes, technical decisions, and source code.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      data-theme="console"
      className="h-full antialiased"
    >
      <body className="min-h-full flex flex-col">{children}<ThemeControls /></body>
    </html>
  );
}
